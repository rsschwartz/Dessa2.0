package selfassembly;

/**
* This class holds the information of <code>AssemblyNode</code>s. Each 
* <code>AssemblyNode</code> has an assembly id, a number of subunits, pointers 
* to previous and next assemblies in the assembly network and an eventType 
* specifying how the assembly was formed 
* 
* @author Greg Smith
* @version 2.0
*
*
*/

public class AssemblyNode {

	/** Assembly ID for the assembly*/
	private int myID;
	
	/** How many subunits are in the assembly*/
	private int numSubunits;
	
	/** The time in the simulation when the assembly is formed*/
	private double simTime;
	
	/** The first of two potential assemblies that participated in forming this assembly*/
	private int prev1;
	
	/** The second of two potential assemblies that participated in forming this assembly - only used if assembly
	 * formed during a bond forming reaction*/
	private int prev2;
	
	/** The first of two potential assemblies that are formed from the current assembly*/
	private int next1;
	
	/** The second of two potential assemblies that are formed from the current assembly - only used if assembly
	 * is involved in a bond breaking reaction*/
	private int next2;
	
	/** Specifies the kind of event involved in the current assembly's formation: -1 means break bond, 1 means form bond*/
	private int eventType;
	
	
	/**
	 * A constructor.
	 * 
	 * @param id - The id of the assembly
	 * @param numsub - The number of subunits in the assembly
	 * @param time - The time of formation of the assembly
	 * @param ev - The type of event involved in assembly formation
	 */
	public AssemblyNode (int id, int numsub, double time, int ev)
	{
		myID = id;
		numSubunits = numsub;
		simTime = time;
		prev1 = 0;
		prev2 = 0;
		next1 = -1;
		next2 = -1;		
		eventType = ev;		
	}	
	
	
	/**
	 * A constructor.
	 * 
	 * @param id - The id of the assembly
	 * @param numsub - The number of subunits in the assembly
	 * @param time - The time of formation of the assembly
	 * @param p1 - Pointer to first previous assembly involved in current assembly formation
	 * @param p2 - Pointer to second previous assembly involved in current assembly formation
	 * @param ev - The type of event involved in assembly formation
	 */
	public AssemblyNode (int id, int numsub, double time, int p1, int p2, int ev)
	{
		myID = id;
		numSubunits = numsub;
		simTime = time;
		prev1 = p1;
		prev2 = p2;
		next1 = -1;
		next2 = -1;		
		eventType = ev;		
	}
	
	/**
	 * A constructor.
	 * 
	 * @param id - The id of the assembly
	 * @param numsub - The number of subunits in the assembly
	 * @param time - The time of formation of the assembly
	 * @param p1 - Pointer to only previous assembly involved in current assembly formation
	 * @param ev - The type of event involved in assembly formation
	 */
	public AssemblyNode (int id, int numsub, double time, int p1, int ev)
	{
		myID = id;
		numSubunits = numsub;
		simTime = time;
		prev1 = p1;
		prev2 = 0;
		next1 = -1;
		next2 = -1;		
		eventType = ev;		
	}
	
	/**
	 * Returns the id of this <code>AssemblyNode</code>
	 * 
	 * @return myID - The id of this <code>AssemblyNode</code>
	 */
	public int getID(){
		return myID;
	}
	
	/**
	 * Returns the number of subunits of this <code>AssemblyNode</code>
	 * 
	 * @return numSubunits - The number of subunits of this <code>AssemblyNode</code>
	 */
	public int getNumSubunits(){
		return numSubunits;
	}
	
	/**
	 * Returns the time of assembly of this <code>AssemblyNode</code>
	 * 
	 * @return simTime - The time of assembly of this <code>AssemblyNode</code>
	 */
	public double getSimTime(){
		return simTime;
	}
	
	/**
	 * Returns a 2 element array of the possible previous assemblies for this <code>AssemblyNode</code>
	 * 
	 * @return A - The array of previous assemblies for this <code>AssemblyNode</code>
	 */
	public int[] getPrev(){
		int[] A = new int[2];
		A[0] = prev1;
		A[1] = prev2;
		return A;
	}
	
	/**
	 * Returns a 2 element array of the possible next assemblies for this <code>AssemblyNode</code>
	 * 
	 * @return A - The array of next assemblies for this <code>AssemblyNode</code>
	 */
	public int[] getNext(){
		int[]A = new int[2];
		A[0] = next1;
		A[1] = next2;
		return A;
	}
	
	/**
	 * Returns the event type responsible for formation of this <code>AssemblyNode</code>
	 * 
	 * @return eventType - The eventType for the formation of this <code>AssemblyNode</code>
	 */
	public int getEventType(){
		return eventType;
	}
	
	/**
	 * Adds two pointers to assemblies created from the current <code>AssemblyNode</code>
	 * This happens when a break bond event breaks the current assembly into separate new assemblies.
	 * 
	 * @param n1 - id of first next assembly
	 * @param n2 - id of second next assembly
	 */
	public void setNext(int n1, int n2){
		next1 = n1;
		next2 = n2;
	}
	
	/**
	 * Adds a single pointer to an assembly created from the current <code>AssemblyNode</code>
	 * This happens when a form bond event occurs between the current assembly and another assembly
	 * forming a third new assembly
	 * 
	 * @param n1 - id of next assembly
	 */
	public void setNext(int n1){
		next1 = n1;
		next2 = 0;
	}
	
	/**
	 * A toString method for debugging
	 */
	public String toString() {
		
		int[] A = new int[2];
		A[0] = prev1;
		A[1] = prev2;
		
		int[]B = new int[2];
		B[0] = next1;
		B[1] = next2;
		
		StringBuffer buff = new StringBuffer();

		buff.append("ID: ");
		buff.append(myID);
		buff.append(" Number of Subunits: ");
		buff.append(numSubunits);
		buff.append(" Previous Nodes: ");
		buff.append(A);
		buff.append(" Next Nodes: ");
		buff.append(B);
		buff.append(" Event Type: ");
		buff.append(eventType);
		buff.append("\n");

		return buff.toString();
	}
	
	
}