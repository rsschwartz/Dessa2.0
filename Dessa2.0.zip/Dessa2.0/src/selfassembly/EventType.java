package selfassembly;

public enum EventType {
	formBndEvt, 
	brkBndEvt, 
	cnfChngEvt
}
