package selfassembly;

import java.io.*;
import java.util.*;

/**
 * The <code>GraphBuilder</code> class acts as an alternative simulation starting point to test.
 * This class is utilized when we want to construct video files of specific simulation runs.
 * The class loads a <code>Simulation</code> from XML, then proceeds to simulate two identical
 * assembly trajectories. Following the first run, the most detailed path from monomer to 
 * largest assembled structure is created. During the second run, graphical information about each 
 * assembly step along that path is recorded and saved for future movie generation. 
 * 
 * @author Gregory Smith
 * @version 2.0
 */

public class GraphBuilder {

	/** Which binding statistics file to use */
	private static String birfinput = "";
	
	/** How many subunits per completed capsid */
	private static int capsidSize = 90;
	
	/** Hash Map of all assembly reactions*/
	public static HashMap<Integer, AssemblyNode> assemblyHashMap;
	
	/** Largest assembly size in simulation*/
	private static int maxSize = 1;
	
	/** ID of the first occurrence of the largest assembly size in simulation */
	private static int maxID = 0;
	
	/** Completed assembly pathway from monomer to largest assembly size*/
	private static StringBuffer path_out;
	
	/** Which xml file to use*/
	public static String xmlFile = "";
	
	/** Controls the number of <code>Event</code>s between outputs*/
	public static String evPerPrint = "1000";
	
	/** Max Simulation time allowed. After which simulation turns off automatically*/
	public static String maxSimTime;
	
	/** The seed used for the random number generator*/
	private static int seedChoice = 0;
	
	/** Determines if a random seed will be predetermined for this simulation*/
	private static boolean isSeed = false;
	
	//public static HashMap<Integer, Integer> pathHashMap;
			
	public static void main(String args[]){
		
		if (args.length == 0) {
			System.out.println("usage: xmlFile.xml [Events Per Printout] [Max Simulation Time] [Capsid Size] [Random Seed] ");
			System.exit(-1);
		}
		
		xmlFile = args[0];
		
		try {
			evPerPrint = args[1];
		} catch (Exception e) {
			evPerPrint = "1000";
		}
		
		try {
			maxSimTime = args[2];
		} catch (Exception e) {
			maxSimTime = "10000";
		}
			
		try {
			capsidSize = Integer.parseInt(args[3]);
		} catch (Exception e) {
			capsidSize = 90;
		}
		
		try {
			seedChoice = Integer.parseInt(args[4]);
			isSeed = true;
		} catch (Exception e) {
			seedChoice = 0;
			isSeed = false;
		}
		
		// The first run of the simulation determines the pathway the capsid uses to assemble
		
		if (isSeed) {
			
			// If there is a specific random seed for this simulation, these args are used in the call to Test
			
			String[] arguments = new String[8];
			arguments[0] = xmlFile;
			arguments[1] = evPerPrint;
			arguments[2] = maxSimTime;
			arguments[3] = "2.56e-7";
			arguments[4] = "145e-6";
			arguments[5] = "250e3";
			arguments[6] = Integer.toString(seedChoice);
			arguments[7] = "200";
			
			Test.main(arguments);				
			
		} else {
			
			// If there isn't a specific random seed, only three args are needed in the call to Test
			
			String[] arguments = new String[3];
			arguments[0] = xmlFile;
			arguments[1] = evPerPrint;
			arguments[2] = maxSimTime;
			
			Test.main(arguments);						
		}
		
		/* birfOutput is the name of an output file from the first simulation run that recorded all bond forming
		 * and breaking reactions. This is necessary for creating the map of reaction events. This output file will
		 * now be the input for developing that map.
		 */
		
		birfinput = "birfOutput";
			
		/* We now create a Hashmap connecting specific assembly ids to individual assembly nodes. Each time a bond forming
		* or breaking reaction occurs in the simulator, at least one new assembly is created and each new assembly is assigned
		* a new assembly id. For each assembly node, we record the id of the assembly, what kind of reaction resulted in 
		* its creation, and pointers to previous assembly(ies) involved in its creation and assembly(ies) that are built from
		* the current assembly. Each pointer is the assembly id of the assembly being pointed to.
		*/
		
		int size = capsidSize;
		assemblyHashMap = new HashMap<Integer, AssemblyNode>(size);
				
		try {
						
			Scanner sc = new Scanner(new File(birfinput));
			
			int seed = 0;
			int numSubunits = 0;
			int operation = 0;
			int size1 = 0;
			int size2 = 0;
			int size3 = 0;
			int id1 = 0;
			int id2 = 0;
			int id3 = 0;
			double time = 0;		
			
			if (sc.hasNext() == true) {
				seed = sc.nextInt();
				System.out.println(seed);
			}
			
			if (sc.hasNext() == true) {
				numSubunits = sc.nextInt();
				System.out.println(numSubunits);
			}
			
			for (int i = 1; i <= numSubunits; ++i) {
				AssemblyNode tem = new AssemblyNode(i,1,0,0);
				assemblyHashMap.put(tem.getID(), tem);				
			}
			
			while (sc.hasNext() == true) {
								
				operation = sc.nextInt();
				size1 = sc.nextInt();
				size2 = sc.nextInt();
				size3 = sc.nextInt();
				id1 = sc.nextInt();
				id2 = sc.nextInt();
				id3 = sc.nextInt();
				time = sc.nextDouble();
				
				if (size2 > maxSize) {
					maxID = id2;
					maxSize = size2;
				}
				
				if (size3 > maxSize) {
					maxID = id3;
					maxSize = size3;					
				}
				
				
				if (operation == -1) {
					
					AssemblyNode tem1 = new AssemblyNode(id2,size2,time,id1,operation);
					AssemblyNode tem2 = new AssemblyNode(id3,size3,time,id1,operation);
					
					assemblyHashMap.put(tem1.getID(), tem1);
					assemblyHashMap.put(tem2.getID(), tem2);
					
					AssemblyNode prev1 = assemblyHashMap.get(id1);
					prev1.setNext(id2, id3);
					
				} else {
					
					AssemblyNode tem1 = new AssemblyNode(id3,size3,time,id1,id2,operation);
					
					assemblyHashMap.put(tem1.getID(), tem1);
					
					AssemblyNode prev1 = assemblyHashMap.get(id1);
					AssemblyNode prev2 = assemblyHashMap.get(id2);
										
					prev1.setNext(id3);
					prev2.setNext(id3);					
					
				}		
				
			}	
			
			/* Now we build the specific path in reverse from largest assembly constructed during the simulation
			 * to a single monomer. When there are two possible paths to choose from, we choose the path with the larger
			 * subassembly to ensure a more detailed path.			
			*/
			
			int lastID = maxID;
			int pointer = lastID;
			System.out.println("The initial id is "+lastID);
			ArrayList<Integer> pathway = new ArrayList<Integer>();
			pathway.add(0,lastID);			
			
			while (pointer != 0) {
				
				AssemblyNode node = assemblyHashMap.get(pointer);
				int p1 = node.getPrev()[0];
				int p2 = node.getPrev()[1];
				int s1 = 0;
				int s2 = 0;
				
				if (p1 != 0) {
					AssemblyNode prev1 = assemblyHashMap.get(p1);
					s1 = prev1.getNumSubunits();
				}
				
				if (p2 != 0) {
					AssemblyNode prev2 = assemblyHashMap.get(p2);
					s2 = prev2.getNumSubunits();					
				}
				
				if (Math.max(s1,s2) == 0) {
					break;
				} else {
					if (s1 >= s2) {
						pathway.add(0,p1);
						pointer = p1;
					} else {
						pathway.add(0,p2);
						pointer = p2;					
					}											
				}				
			}
			
			System.out.println(pathway);
			int listSize = pathway.size();
			System.out.println("The length of the pathway is " + listSize);
			
			// We print out the completed pathway to a txt file formedPath to be read during the second simulation
			
			path_out = new StringBuffer();
			
			for (int i = 0; i < listSize; i++) {
				int assemID = pathway.get(i);
				path_out.append(assemID + "\r\n");
				AssemblyNode temp = assemblyHashMap.get(assemID);
				int tempSize = temp.getNumSubunits();
				double tempTime = temp.getSimTime();
				System.out.println(tempTime + "\t" + assemID + "\t" + tempSize);				
			}
			
			String filename = "/home/grsmith/Desktop/Dessa2.0/formedPath";
						
			File pathf = new File(filename);
			Integer i = 0;
			while(pathf.exists()){
				++i;
				pathf = new File(filename+i.toString());
			}
			
			BufferedWriter pathbw = null;
			pathbw = new BufferedWriter(new FileWriter(pathf, false));
			
			pathbw.write(path_out.toString());
			pathbw.close();		
			
			/* We use the same input arguments as the first simulation including the random seed from the first run plus a
			 * final argument that specifies the formedPath path which will be used to generate the individual frames for the movie
			*/
			
			String[] roundTwo = new String[9];
			roundTwo[0] = xmlFile;
			roundTwo[1] = evPerPrint;
			roundTwo[2] = maxSimTime;
			roundTwo[3] = "2.56e-7";
			roundTwo[4] = "145e-6";
			roundTwo[5] = "250e3";
			roundTwo[6] = Integer.toString(seed);
			roundTwo[7] = "200";
			roundTwo[8] = filename;
			
			Test.main(roundTwo);
						
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
}
