package selfassembly;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;

import javax.vecmath.AxisAngle4d;
import javax.vecmath.Matrix4d;
import javax.vecmath.Vector3d;

/**
 * The <code>Test</code> class loads a <code>Simulation</code> 
 * from XML, starts it and lists important control variables. 
 * 
 * @author Rori Rohlfs
 * @author Tiequan Zhang
 * @author Blake Sweeney
 * @author Rupinder Khandpur
 * @author Gregory Smith
 * @version 2.0
 */
public class Test  {

	/* ******************** Output Modifiers ********************/

	/** Controls the number of <code>Event</code>s between outputs */
	public static int eventsPerPrint = 1000;

	/** Whether or not to print the <code>Conformation</code> distribution */
	public static boolean printConfDist = false;

	/** Maximum size for which distribution statistics are printed */
	public static int maxOutputSize = 8;

	/* ******************** General Values ********************/

	/** The name for this Simulation type */
	public static String simType = "xml";

	/** Which xml file to use */
	public static String mode = "";

	/** Mass for a <code>Subunit</code> */
	public static double subMass = 3.4;

	/** Ratio of <code>Subunit</code> to <code>BindingSite</code>, should be <=0.5 */
	public static double subunitToBS = 0.5;

	/** Height of a <code>BindingSite</code> */
	public static float bindingSiteHeight = 0.10f;

	/** Radius for a <code>Subunit</code> */
	public static double subRadius = bindingSiteHeight * subunitToBS;


	/* ******************** Simulation Variables ********************/

	/** Use the diffusion model */
	//public static boolean diffusionEnabled = false;

	/** Pick events that only allow monomer binding */
	public static boolean bindMonomerOnly = false;

	/** only sample breaking event for bonds not involving a loop */
	public static boolean noLoopOnly = true;

	/** For filament assembly, allow only monomers break off */
	public static boolean breakOnlyEnds = false;

	/** Enable conformational switching event sampling */
	public static boolean csAllowed = true;

	/** The int returned from Assemblies.numbSubunits() that will be treated as a monomer */
	public static int sizeOfSubunit = 1;

	/**  Maximum allowed assembly size */
	public static int maxLength = 360;

	/** The amount of volume to search for nearest neighbors */
	public static double binSize = 0.1;

	/** The distance tolerance for loop detection*/
	public static double distanceTolerance = 0.1;

	/** Controls whether or not the Spring Force model is used */
	public static boolean springForce = false;


	/* ******************** Random Number Generator ********************/

	/** The Random number generator for the simulation */
	public static Random rand;

	/** The random number generator for the seed */
	public static Random seedGenerator;

	/** The seed used for the random number generator */
	public static int seedUsed;

	/** Max Simulation time allowed. After which simulation turns off automatically */
	public static double maxSimulationTime;

	
	/* ********************* Pathway Visualization Analysis ****************/
	
	/** The file name for a pre-defined pathway of a completed capsid structure for a specified random seed*/
	public static String pathFileName = ""; 
	
	/** Controls whether or not we develop a vector file for a pre-defined pathway */
	public static boolean visOn = false;
	
	/** List of assembly id's present in the pre-defined pathway*/
	public static HashMap<Integer, Integer> pathHashMap;
	
	public static double kXcXw;
		
	/**
	 * main method to start the simulator
	 */
	public static void main(String args[]) {

		if (args.length == 0) {
			System.out.println("usage: xmlFile.xml [Events Per Printout] " +
			"[Max Simulation Time] [k-Const] [c-Const] [mol. wt Const] [Random Seed] [Max Output Size] [Assembly Path File Name]");
			System.exit(-1);
		}

		mode = args[0];
		double k;
		double c;
		double m;
		try {
			eventsPerPrint = Integer.parseInt(args[1]);
		} catch (Exception e) {
			eventsPerPrint = 10000;
		}

		try {
			maxSimulationTime = Double.parseDouble(args[2]);
		} catch (Exception e ) {
			maxSimulationTime =  Double.MAX_VALUE;
		}
		try {//k const
			k = Double.parseDouble(args[3]);
		} catch (Exception e) {
			k = 2.56e-7;
		}

		try {//c const
			c = Double.parseDouble(args[4]);
		} catch (Exception e) {
			c = 145e-6;
		}
		
		try {//mol weight const
			m = Double.parseDouble(args[5]);
		} catch (Exception e) {
			m = 250e3;
		}
		
		kXcXw = k*c*m;//constants for rTheta calculation
		
		try {
			seedUsed = Integer.parseInt(args[6]);
		} catch (Exception e ) {
			seedGenerator = new Random();
			seedUsed = seedGenerator.nextInt();
		}
		
		rand = new Random(seedUsed);
		
		try {
			maxOutputSize = Integer.parseInt(args[7]);
		} catch(Exception e) {
			maxOutputSize = 200;
		}
		
		// PathFileName specifies an assembly path to be input to produce an assembly movie
		// It is only present if we're running DESSA from GraphBuilder.java
		
		try {
			pathFileName = args[8];
		} catch(Exception e){
			pathFileName = "";
		}
				
		pathHashMap = new HashMap<Integer,Integer>();
		pathHashMap.put(0, 0);
				
		if (!pathFileName.equals("")){
						
			try {
				
				System.out.println(pathFileName);
				
				Scanner sc = new Scanner(new File(pathFileName));
				
				int newID = -1;
								
				while (sc.hasNext() == true) {
					newID = sc.nextInt();
					System.out.println(newID);
					pathHashMap.put(newID,0);										
				}
				
				//System.out.println(pathHashMap);
				
				visOn = true;
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
		System.out.println(String.format("Input : %s Seed: %d (Dessa v1.5.7, Bio.Phys.)",mode, seedUsed));
		
		for(int i=0;i<1;i++){
			
			System.out.println(pathHashMap);
			
			XMLReader reader = null;
			try {
				reader = new XMLReader(mode);
			} catch (Exception e) {
				e.printStackTrace();
			}

			Simulation sim  = reader.getSim();
			
			sim.run();
		}
				
	}



	/**
	 * Rotates a Vector around an axis by the specified angle.
	 * 
	 * @param v - The vector to rotate
	 * @param a - the AxisAngle to rotate around
	 * @return Vector3d - the rotated Vector3d
	 */
	public static Vector3d rotateByAxis(Vector3d v, AxisAngle4d a) {

		Matrix4d m = new Matrix4d();
		m.set(a);
		Vector3d rv = new Vector3d();
		m.transform(v, rv);
		return rv;
	}




	/**
	 * 
	 * @param axis
	 * @param upV
	 * @return
	 */
	public static Vector3d makePerpendicular(Vector3d axis, Vector3d upV) {

		double angle = axis.angle(upV);

		Vector3d projectedV = new Vector3d();

		if (angle < 0.00001 || (Math.PI-angle)<0.00001 ) {
			System.out.println("Bad_choice_in_upVector");
			System.exit(0);
		} else {

			Vector3d tem = new Vector3d(axis);
			tem.scale(axis.dot(upV) / axis.lengthSquared());

			projectedV.sub(upV, tem);
		}
		projectedV.normalize();

		return projectedV;
	}
}
